select * from ordenesdecompra;
select * from stock;
select * from boleta;