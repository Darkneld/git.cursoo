create table if not exists categoria(
id integer not null auto_increment primary key,
categoria varchar (50)
);