create table if not exists ordenesdecompra(
id integer not null auto_increment primary key,
cantidad integer,
preciounitario integer,
preciototal integer,
cliente integer,
trabajadores integer,
metodosdepago integer,
producto integer,
boleta integer,
foreign key (cliente) references cliente(id),
foreign key (trabajadores) references trabajadores(id),
foreign key (metodosdepago) references  metodosdepago(id),
foreign key (producto) references producto(id),
foreign key (boleta) references boleta(id)
);