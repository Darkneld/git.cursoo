create database if not exists PCF character set utf8mb4 collate utf8mb4_spanish_ci;
use PCF;