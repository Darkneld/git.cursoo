delimiter $$
create procedure ingresotrabajadores(
in _nombre varchar(100),
in _apellido varchar(100),
in _rut varchar(13),
in _correo varchar(100),
in _telefono varchar(12),
in _cargo varchar(100),
in _ubicacion integer
)
begin
insert into trabajadores(nombre,apellido,rut,correo,telefono,cargo,ubicacion) values (_nombre,_apellido,_rut,_correo,_telefono,_cargo,_ubicacion);
END$$
delimiter ;