delimiter $$
create procedure ingresocategoria(
in _categoria varchar(50)
)
begin
insert into categoria(categoria) values (categoria);
END$$
delimiter ;