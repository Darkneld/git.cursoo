delimiter $$
create procedure Selects()
begin
SHOW FULL TABLES FROM PCF;
select * from ordenesdecompra;
select * from stock;
select * from boleta;
/*+---------------------------------------------------------------------------------------------------------------------+*/
/*|*/select a.cantidad, a.ubicacion, b.nombre, b.precio, b.descripcion, b.fichatecnica, b.categoria, b.marca, b.stock /*|*/
/*|*/from stock a inner join producto b                                                                               /*|*/     #----------------------------------> ESTE ES EL STOCK EXISTENTE EN TODAS LAS SEDES
/*|*/on a.id=b.id;                                                                                                    /*|*/
/*+---------------------------------------------------------------------------------------------------------------------+*/
END$$
delimiter ;