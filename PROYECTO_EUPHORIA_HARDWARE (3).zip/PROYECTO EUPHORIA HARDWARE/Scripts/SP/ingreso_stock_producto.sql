delimiter $$
create procedure ingreso_stock_producto(
#---------atributos stock---------#
in _cantidad integer,
in _ubicacion integer,
#---------atributos producto---------#
in _nombre varchar(50),
in _precio integer,
in _descripcion text,
in _fichatecnica text,
in _categoria integer,
in _marca integer,
in _stock integer
)
begin
insert into stock(cantidad,ubicacion) values (_cantidad,_ubicacion);
insert into producto(nombre,precio,descripcion,fichatecnica,categoria,marca,stock) values (_nombre,_precio,_descripcion,_fichatecnica,_categoria,_marca,_stock);
END$$
delimiter ;