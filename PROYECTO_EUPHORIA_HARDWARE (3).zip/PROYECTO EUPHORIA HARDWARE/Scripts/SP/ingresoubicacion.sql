delimiter $$
create procedure ingresoubicacion(
in _ubicacion varchar(20)
)
begin
insert into ubicacion(ubicacion) values (_ubicacion);
END$$
delimiter ;