delimiter $$
create procedure ingresomarca(
in _nombre varchar(20),
in _descripcion text
)
begin
insert into marca(nombre,descripcion) values (_nombre,_descripcion);
END$$
delimiter ;