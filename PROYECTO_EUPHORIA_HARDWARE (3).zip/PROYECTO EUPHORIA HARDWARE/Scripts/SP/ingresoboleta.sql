delimiter $$
create procedure ingresoboleta(
in _cantidad integer,
in _cliente integer,
in _trabajadores integer,
in _metodosdepago integer,
in _producto integer,
in _preciototal integer
)
begin
insert into boleta(cantidad,cliente,trabajadores,metodosdepago,producto,preciototal) values (_cantidad,_cliente,_trabajadores,_metodosdepago,_producto,_preciototal);
END$$
delimiter ;