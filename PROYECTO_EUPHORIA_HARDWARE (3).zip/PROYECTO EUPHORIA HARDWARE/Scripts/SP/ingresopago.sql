delimiter $$
create procedure ingresopago(
in _metodopago varchar(8)
)
begin
insert into metodosdepago(metodopago) values (_metodopago);
END$$
delimiter ;