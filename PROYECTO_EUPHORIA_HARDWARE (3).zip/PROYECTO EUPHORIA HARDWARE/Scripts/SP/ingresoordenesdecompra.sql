delimiter $$
create procedure ingresoordenesdecompra(
in _cantidad integer,
in _cliente integer,
in _trabajadores integer,
in _metodosdepago integer,
in _producto integer,
in _preciototal integer,
in _preciounitario integer,
in _boleta integer
)
begin
insert into ordenesdecompra(cantidad,cliente,trabajadores,metodosdepago,producto,preciototal,preciounitario,boleta) values (_cantidad,_cliente,_trabajadores,_metodosdepago,_producto,_preciototal,_preciounitario,_boleta);
END$$
delimiter ;