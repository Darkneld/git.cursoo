call ingreso_stock_producto('20','17','smartphone_01','600990','null','null','1','7','1');#ID-1
call ingreso_stock_producto('47','9','componente_01','329990','null','null','3','5','2');#ID-2
call ingreso_stock_producto('107','7','colexionable_01','8990','null','null','9','8','3');#ID-3
call ingreso_stock_producto('7','27','ups_01','147990','null','null','22','4','4');#ID-4
call ingreso_stock_producto('67','12','consola_01','499990','null','null','6','2','5');#ID-5
call ingreso_stock_producto('86','2','colexionable_01','8990','null','null','9','8','6');#ID-6