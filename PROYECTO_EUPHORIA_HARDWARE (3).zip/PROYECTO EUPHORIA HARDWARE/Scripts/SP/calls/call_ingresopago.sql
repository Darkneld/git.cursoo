call ingresopago ('debito');#- ID-1
call ingresopago ('credito');#-ID-2
call ingresopago ('efectivo');#-ID-3