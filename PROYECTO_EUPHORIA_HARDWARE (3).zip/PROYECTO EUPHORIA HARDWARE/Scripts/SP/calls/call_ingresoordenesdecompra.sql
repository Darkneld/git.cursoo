call ingresoordenesdecompra('4','2','6','3','6','35960','8990','1'); 
																				   #call ingresoordenesdecompra('4','2','6','3','6','35960','8990','1');  
																				   #                             |   |   |   |   |     |      |     |--------> HACE REFERENCIA A LA BOLETA RELACIONADA A LA ORDENDECOMPRA
                                                                                   #                             |   |   |   |   |     |      |--------> VALOR DE EL PRODUCTO POR UNIDAD
                                                                                   #                             |   |   |   |   |     |--------> VALOR DEL LOS PRODUCTOS TOTAL
                                                                                   #                             |   |   |   |   |--------> ID TABLA PRODUCTO (saber el producto que se esta vendiendo)
                                                                                   #                             |   |   |   |--------> ID TABLA METODOSDEPAGO (saber cual de los 3 metodos de pago uso)
                                                                                   #                             |   |   |--------> ID TABLA TRABAJADORES (saber quien esta por vender x producto)
                                                                                   #                             |   |--------> ID TABLA TRABAJADORES (saber quien es el comprador)
                                                                                   #                             |--------> CANTIDAD DE PRODUCTO COMPRADO 