call ingresoboleta('4','2','6','3','6','35960');  
                                                          #call ingresoboleta('4','2','6','3','6','35960');
													      # 		           |   |   |   |   |     |--------> PRECIO TOTAL (la suma del total del valor de los productos listados)
                                                          #					   |   |   |   |   |-------> ID TABLA PRODUCTO	(saber el producto que se vendio )	    
                                                          #                    |   |   |   |--------> ID TABLA METODOSDEPAGO (saber cual de los 3 metodos de pago uso)
                                                          #                    |   |   |--------> ID TABLA TRABAJADORES (saber quien vendio x producto)
                                                          #                    |   |--------> ID TABLA CLIENTE (saber a quien se vendio x producto)
                                                          #                    |--------> CANTIDAD DE PRODUCTO COMPRADO 