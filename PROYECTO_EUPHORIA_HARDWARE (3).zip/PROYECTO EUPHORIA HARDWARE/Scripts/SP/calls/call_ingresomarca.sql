call ingresomarca('marca_01',null);
call ingresomarca('marca_02',null);
call ingresomarca('marca_03',null);
call ingresomarca('marca_04',null);
call ingresomarca('marca_05',null);
call ingresomarca('marca_06',null);
call ingresomarca('marca_07',null);
call ingresomarca('marca_08',null);