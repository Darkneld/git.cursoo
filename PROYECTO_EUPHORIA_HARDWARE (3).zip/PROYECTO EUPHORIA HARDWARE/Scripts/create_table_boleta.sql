create table if not exists boleta(
id integer not null auto_increment primary key,
cantidad integer,
preciototal integer,
cliente integer,
trabajadores integer,
metodosdepago integer,
producto integer,
foreign key (cliente) references cliente(id),
foreign key (trabajadores) references trabajadores(id),
foreign key (metodosdepago) references  metodosdepago(id),
foreign key (producto) references producto(id)
);