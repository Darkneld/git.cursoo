create table if not exists marca(
id integer not null auto_increment primary key,
nombre varchar(20)not null,
descripcion text
);