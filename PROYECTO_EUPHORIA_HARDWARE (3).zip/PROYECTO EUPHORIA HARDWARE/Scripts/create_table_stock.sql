create table if not exists stock(
id integer not null auto_increment primary key,
cantidad integer,
ubicacion integer,
foreign key (ubicacion) references ubicacion(id)
);