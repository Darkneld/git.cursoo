create table if not exists trabajadores(
id integer not null auto_increment primary key,
nombre varchar(100)not null,
apellido varchar(100)not null,
rut varchar(100)not null,
correo varchar(100)not null,
telefono varchar(100)not null,
cargo varchar(100)not null,
ubicacion integer,
foreign key (ubicacion) references ubicacion(id)
);