create table if not exists ubicacion(
id integer not null auto_increment primary key,
ubicacion varchar(20)not null
);