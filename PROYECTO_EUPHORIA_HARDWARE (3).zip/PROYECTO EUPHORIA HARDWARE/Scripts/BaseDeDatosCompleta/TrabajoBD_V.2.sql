create database if not exists PCF character set utf8mb4 collate utf8mb4_spanish_ci;
use PCF;

create table if not exists categoria(         
id integer not null auto_increment primary key, 
categoria varchar (50)
);
create table if not exists metodosdepago(
id integer not null auto_increment primary key,
metodopago varchar (8)
);
create table if not exists marca(
id integer not null auto_increment primary key,
nombre varchar(20)not null,
descripcion text
);
create table if not exists ubicacion(
id integer not null auto_increment primary key,
ubicacion varchar(20)not null
);
create table if not exists cliente(
id integer not null auto_increment primary key,
nombre varchar(100)not null,
apellido varchar(100)not null,
rut varchar(100)not null,
correo varchar(100)not null,
telefono varchar(100)not null,
ubicacion integer,
foreign key (ubicacion) references ubicacion(id)
);
create table if not exists trabajadores(
id integer not null auto_increment primary key,
nombre varchar(100)not null,
apellido varchar(100)not null,
rut varchar(100)not null,
correo varchar(100)not null,
telefono varchar(100)not null,
cargo varchar(100)not null,
ubicacion integer,
foreign key (ubicacion) references ubicacion(id)
);
create table if not exists stock(
id integer not null auto_increment primary key,
cantidad integer,
ubicacion integer,
foreign key (ubicacion) references ubicacion(id)
);
create table if not exists producto(
id integer not null auto_increment primary key,
nombre varchar(100),
precio integer,
descripcion text,
fichatecnica text,
categoria integer,
marca integer,
stock integer,
foreign key (categoria) references categoria(id),
foreign key (marca) references marca(id),
foreign key (stock) references stock(id)
);
create table if not exists boleta(
id integer not null auto_increment primary key,
cantidad integer,
preciototal integer,
cliente integer,
trabajadores integer,
metodosdepago integer,
producto integer,
foreign key (cliente) references cliente(id),
foreign key (trabajadores) references trabajadores(id),
foreign key (metodosdepago) references  metodosdepago(id),
foreign key (producto) references producto(id)
);
create table if not exists ordenesdecompra(
id integer not null auto_increment primary key,
cantidad integer,
preciounitario integer,
preciototal integer,
cliente integer,
trabajadores integer,
metodosdepago integer,
producto integer,
boleta integer,
foreign key (cliente) references cliente(id),
foreign key (trabajadores) references trabajadores(id),
foreign key (metodosdepago) references  metodosdepago(id),
foreign key (producto) references producto(id),
foreign key (boleta) references boleta(id)                   
);
#---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------#

#---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------#
delimiter $$
create procedure ingresocategoria(
in _categoria varchar(50)
)
begin
insert into categoria(categoria) values (categoria);
END$$
delimiter ;
call ingresocategoria('celulares');#ID-1
call ingresocategoria('computadores');#ID-2
call ingresocategoria('componentes');#ID-3
call ingresocategoria('tv');#-ID4
call ingresocategoria('lineablanca');#ID-5
call ingresocategoria('juegos_consola');#ID-6
call ingresocategoria('codigos_digitales');#ID-7
call ingresocategoria('scooters_electricos');#ID-8
call ingresocategoria('coleccionables');#ID-9
call ingresocategoria('conectividad_y_redes');#ID-10
call ingresocategoria('impresoras_y_suministros');#ID-11
call ingresocategoria('monitores_y_proyectores');#ID-12
call ingresocategoria('oficinias_y_puntos_de_venta');#ID-13
call ingresocategoria('software');#ID-14
call ingresocategoria('conferencias_y_reuniones');#ID-15
call ingresocategoria('audio');#ID-16
call ingresocategoria('dj_y_sonido');#ID-17
call ingresocategoria('automovil');#-ID18
call ingresocategoria('fotografia_video_y_drones');#ID-19
call ingresocategoria('robotica_y_electronica');#ID-20
call ingresocategoria('seguridad_y_smarthhome');#ID-21
call ingresocategoria('ups_y_energia');#ID-22
call ingresocategoria('producto_de_segundamano');#ID-23
call ingresocategoria('servicios');#ID-24
call ingresocategoria('servicios');#ID-25
call ingresocategoria('discoduro_y_almacenamiento');#ID-26
#---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------#
delimiter $$
create procedure ingresomarca(
in _nombre varchar(20),
in _descripcion text
)
begin
insert into marca(nombre,descripcion) values (_nombre,_descripcion);
END$$
delimiter ;
call ingresomarca('marca_01',null);
call ingresomarca('marca_02',null);
call ingresomarca('marca_03',null);
call ingresomarca('marca_04',null);
call ingresomarca('marca_05',null);
call ingresomarca('marca_06',null);
call ingresomarca('marca_07',null);
call ingresomarca('marca_08',null);
#---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------#
delimiter $$
create procedure ingresoubicacion(
in _ubicacion varchar(20)
)
begin
insert into ubicacion(ubicacion) values (_ubicacion);
END$$
delimiter ;
call ingresoubicacion('internet');#ID-1
call ingresoubicacion('calama');#ID-2
call ingresoubicacion('antofagasta');#ID-3
call ingresoubicacion('laserena');#ID-4
call ingresoubicacion('viñadelmar');#ID-5
call ingresoubicacion('agustinas');#ID-6
call ingresoubicacion('cantagallo');#ID-7
call ingresoubicacion('huerfanos');#ID-8
call ingresoubicacion('lascondes');#ID-9
call ingresoubicacion('manuelmont');#ID-10
call ingresoubicacion('mallarauco');#ID-11
call ingresoubicacion('mallcostaneracenter');#ID-12
call ingresoubicacion('mallplazaalameda');#ID-13
call ingresoubicacion('mallplazanorte');#ID-14
call ingresoubicacion('mallplazaoeste');#ID-15
call ingresoubicacion('mallfloridacenter');#ID-16
call ingresoubicacion('rancagua');#ID-17
call ingresoubicacion('curico');#ID-18
call ingresoubicacion('talca');#ID-19
call ingresoubicacion('chillan');#ID-20
call ingresoubicacion('talcahuano');#ID-21
call ingresoubicacion('concepcion');#ID-22
call ingresoubicacion('losangeles');#ID-23
call ingresoubicacion('temuco');#ID-24
call ingresoubicacion('valdivia');#ID-25
call ingresoubicacion('osorno');#ID-26
call ingresoubicacion('puertomont');#ID-27
#---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------#
delimiter $$
create procedure ingresocliente(
in _nombre varchar(100),
in _apellido varchar(100),
in _rut varchar(13),
in _correo varchar(100),
in _telefono varchar(12),
in _ubicacion integer
)
begin
insert into cliente(nombre,apellido,rut,correo,telefono,ubicacion) values (_nombre,_apellido,_rut,_correo,_telefono,_ubicacion);
END$$
delimiter ;
call ingresocliente('nombre_01','apellido_01','rut_01','correo_01','telefono_01','1');#ID-1
call ingresocliente('nombre_02','apellido_02','rut_02','correo_02','telefono_02','2');#ID-2
call ingresocliente('nombre_03','apellido_03','rut_03','correo_03','telefono_03','3');#ID-3
call ingresocliente('nombre_04','apellido_04','rut_04','correo_04','telefono_04','4');#ID-4
call ingresocliente('nombre_05','apellido_05','rut_05','correo_05','telefono_05','5');#ID-5
call ingresocliente('nombre_06','apellido_06','rut_06','correo_06','telefono_06','6');#ID-6
call ingresocliente('nombre_07','apellido_07','rut_07','correo_07','telefono_07','7');#ID-7
call ingresocliente('nombre_08','apellido_08','rut_08','correo_08','telefono_08','8');#ID-8
call ingresocliente('nombre_09','apellido_09','rut_09','correo_09','telefono_09','9');#ID-9
call ingresocliente('nombre_10','apellido_10','rut_10','correo_10','telefono_10','10');#ID-10
call ingresocliente('nombre_11','apellido_11','rut_11','correo_11','telefono_11','11');#ID-12
call ingresocliente('nombre_12','apellido_12','rut_12','correo_12','telefono_12','12');#ID-13
call ingresocliente('nombre_13','apellido_13','rut_13','correo_13','telefono_13','13');#ID-14
call ingresocliente('nombre_14','apellido_14','rut_14','correo_14','telefono_14','14');#ID-15
call ingresocliente('nombre_15','apellido_15','rut_15','correo_15','telefono_15','15');#ID-16
call ingresocliente('nombre_16','apellido_16','rut_16','correo_16','telefono_16','16');#ID-17
call ingresocliente('nombre_17','apellido_17','rut_17','correo_17','telefono_17','17');#ID-18
call ingresocliente('nombre_18','apellido_18','rut_18','correo_18','telefono_18','18');#ID-19
call ingresocliente('nombre_19','apellido_19','rut_19','correo_19','telefono_19','19');#ID-20
call ingresocliente('nombre_20','apellido_20','rut_20','correo_20','telefono_20','20');#ID-21
call ingresocliente('nombre_21','apellido_21','rut_21','correo_21','telefono_21','21');#ID-22
call ingresocliente('nombre_22','apellido_22','rut_22','correo_22','telefono_22','22');#ID-23
call ingresocliente('nombre_23','apellido_23','rut_23','correo_23','telefono_23','23');#ID-24
call ingresocliente('nombre_24','apellido_24','rut_24','correo_24','telefono_24','24');#ID-25
call ingresocliente('nombre_25','apellido_25','rut_25','correo_25','telefono_25','25');#ID-26
call ingresocliente('nombre_26','apellido_26','rut_26','correo_26','telefono_26','26');#ID-27
call ingresocliente('nombre_27','apellido_27','rut_27','correo_27','telefono_27','27');#ID-28
#---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------#
delimiter $$
create procedure ingresotrabajadores(
in _nombre varchar(100),
in _apellido varchar(100),
in _rut varchar(13),
in _correo varchar(100),
in _telefono varchar(12),
in _cargo varchar(100),
in _ubicacion integer
)
begin
insert into trabajadores(nombre,apellido,rut,correo,telefono,cargo,ubicacion) values (_nombre,_apellido,_rut,_correo,_telefono,_cargo,_ubicacion);
END$$
delimiter ;
call ingresotrabajadores('nombre_01','apellido_01','rut_01','correo_01','telefono_01','cargo_01','1');#ID-1
call ingresotrabajadores('nombre_02','apellido_02','rut_02','correo_02','telefono_02','cargo_02','1');#ID-2
call ingresotrabajadores('nombre_03','apellido_03','rut_03','correo_03','telefono_03','cargo_03','1');#ID-3
call ingresotrabajadores('nombre_04','apellido_04','rut_04','correo_04','telefono_04','cargo_04','1');#ID-4
call ingresotrabajadores('nombre_05','apellido_05','rut_05','correo_05','telefono_05','cargo_05','1');#ID-5
call ingresotrabajadores('nombre_06','apellido_06','rut_06','correo_06','telefono_06','cargo_06','2');#ID-6
call ingresotrabajadores('nombre_07','apellido_07','rut_07','correo_07','telefono_07','cargo_07','2');#ID-7
call ingresotrabajadores('nombre_08','apellido_08','rut_08','correo_08','telefono_08','cargo_08','2');#ID-8
call ingresotrabajadores('nombre_09','apellido_09','rut_09','correo_09','telefono_09','cargo_09','2');#ID-9
call ingresotrabajadores('nombre_10','apellido_10','rut_10','correo_10','telefono_10','cargo_10','2');#ID-10
#---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------#
delimiter $$
create procedure ingresopago(
in _metodopago varchar(8)
)
begin
insert into metodosdepago(metodopago) values (_metodopago);
END$$
delimiter ;
call ingresopago ('debito');#ID-1
call ingresopago ('credito');#ID-2
call ingresopago ('efectivo');#ID-3
#---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------#
delimiter $$
create procedure ingreso_stock_producto(
#---------atributos stock---------#
in _cantidad integer,
in _ubicacion integer,
#---------atributos producto---------#
in _nombre varchar(50),
in _precio integer,
in _descripcion text,
in _fichatecnica text,
in _categoria integer,
in _marca integer

)
begin
insert into stock(cantidad,ubicacion) values (_cantidad,_ubicacion);
insert into producto(nombre,precio,descripcion,fichatecnica,categoria,marca) values (_nombre,_precio,_descripcion,_fichatecnica,_categoria,_marca);
END$$
delimiter ;
call ingreso_stock_producto('20','17','smartphone_01','600990','null','null','1','7');#ID-1          #call ingreso_stock_producto('20','17','smartphone_01','600990','null','null','1','7');
call ingreso_stock_producto('47','9','componente_01','329990','null','null','3','5');#ID-2           #                             |    |          |            |       |      |    |   |--------> ID TABLA "marca" (saber a que marca pertenece el producto)                                                      
call ingreso_stock_producto('107','7','colexionable_01','8990','null','null','9','8');#ID-3          #                             |    |          |            |       |      |    |--------> ID TABLA "categoria" (saber a que categoria pertenece el producto)                    
call ingreso_stock_producto('7','27','ups_01','147990','null','null','22','4');#ID-4                 #                             |    |          |            |       |      |--------> FICHA TECNICA DEL PRODUCTO
call ingreso_stock_producto('67','12','consola_01','499990','null','null','6','2');#ID-5             #                             |    |          |            |       |-------->DESCRIPCION DEL PRODUCTO
call ingreso_stock_producto('86','2','colexionable_01','8990','null','null','9','8');#ID-6           #                             |    |          |            |--------> PRECIO DEL PRODUCTO
																									 #                             |    |          |--------> NOMBRE DEL PRODUCTO
																									 #                             |    |--------> ID TABLA "ubicacion" (saber en donde se encuentra el producto)
																									 #                             |--------> EXISTENCIAS DEL PRODUCTO
#---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------#
delimiter $$
create procedure ingresoboleta(
in _cantidad integer,
in _cliente integer,
in _trabajadores integer,
in _metodosdepago integer,
in _producto integer,
in _preciototal integer
)
begin
insert into boleta(cantidad,cliente,trabajadores,metodosdepago,producto,preciototal) values (_cantidad,_cliente,_trabajadores,_metodosdepago,_producto,_preciototal);
END$$
delimiter ;
call ingresoboleta('4','2','6','3','6','35960');#ID-1     #call ingresoboleta('4','2','6','3','6','35960');
													      # 		           |   |   |   |   |     |--------> PRECIO TOTAL (la suma del total del valor de los productos listados)
                                                          #					   |   |   |   |   |-------> ID TABLA "producto" (saber el producto que se vendio )	    
                                                          #                    |   |   |   |--------> ID TABLA "metodosdepago" (saber cual de los 3 metodos de pago uso)
                                                          #                    |   |   |--------> ID TABLA "trabajadores" (saber quien vendio x producto)
                                                          #                    |   |--------> ID TABLA "cliente" (saber a quien se vendio x producto)
                                                          #                    |--------> CANTIDAD DE PRODUCTO COMPRADO 
#---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------#
delimiter $$
create procedure ingresoordenesdecompra(
in _cantidad integer,
in _cliente integer,
in _trabajadores integer,
in _metodosdepago integer,
in _producto integer,
in _preciototal integer,
in _preciounitario integer,
in _boleta integer
)
begin
insert into ordenesdecompra(cantidad,cliente,trabajadores,metodosdepago,producto,preciototal,preciounitario,boleta) values (_cantidad,_cliente,_trabajadores,_metodosdepago,_producto,_preciototal,_preciounitario,_boleta);
END$$
delimiter ;
call ingresoordenesdecompra('4','2','6','3','6','35960','8990','1');#ID-1          #call ingresoordenesdecompra('4','2','6','3','6','35960','8990','1');  
																				   #                             |   |   |   |   |     |      |     |--------> HACE REFERENCIA A LA BOLETA RELACIONADA A LA ORDENDECOMPRA
                                                                                   #                             |   |   |   |   |     |      |--------> VALOR DE EL PRODUCTO POR UNIDAD
                                                                                   #                             |   |   |   |   |     |--------> VALOR DEL LOS PRODUCTOS TOTAL
                                                                                   #                             |   |   |   |   |--------> ID TABLA "producto" (saber el producto que se esta vendiendo)
                                                                                   #                             |   |   |   |--------> ID TABLA "metodosdepago" (saber cual de los 3 metodos de pago uso)
                                                                                   #                             |   |   |--------> ID TABLA "trabajadores" (saber quien esta por vender x producto)
                                                                                   #                             |   |--------> ID TABLA "cliente" (saber quien es el comprador)
                                                                                   #                             |--------> CANTIDAD DE PRODUCTO COMPRADO 
#---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------#

#---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------#
delimiter $$
create procedure Selects()
begin
SHOW FULL TABLES FROM PCF;
select * from ordenesdecompra;
select * from stock;
select * from boleta;
/*+---------------------------------------------------------------------------------------------------------------------+*/
/*|*/select a.cantidad, a.ubicacion, b.nombre, b.precio, b.descripcion, b.fichatecnica, b.categoria, b.marca, b.stock /*|*/
/*|*/from stock a inner join producto b                                                                               /*|*/     #----------------------------------> ESTE ES EL STOCK EXISTENTE EN TODAS LAS SEDES
/*|*/on a.id=b.id;                                                                                                    /*|*/
/*+---------------------------------------------------------------------------------------------------------------------+*/
END$$
delimiter ;
call Selects;
#---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------#

                           
