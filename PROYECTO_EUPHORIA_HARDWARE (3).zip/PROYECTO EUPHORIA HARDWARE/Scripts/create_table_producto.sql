create table if not exists producto(
id integer not null auto_increment primary key,
nombre varchar(100),
precio integer,
descripcion text,
fichatecnica text,
categoria integer,
marca integer,
stock integer,
foreign key (categoria) references categoria(id),
foreign key (marca) references marca(id),
foreign key (stock) references stock(id)
);