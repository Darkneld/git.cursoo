create table if not exists metodosdepago(
id integer not null auto_increment primary key,
metodopago varchar (8)
);